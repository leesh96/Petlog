package swpj.petlog.petlog2;

public class PetstaPostData {
    private int member_id;
    private String member_content;

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public String getMember_contents() {
        return member_content;
    }

    public void setMember_contents(String member_contents) {
        this.member_content = member_content;
    }
}
