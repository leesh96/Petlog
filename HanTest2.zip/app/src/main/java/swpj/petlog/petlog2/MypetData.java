package swpj.petlog.petlog2;

public class MypetData {
    private int member_id;
    private String member_name;
    private String member_sex;
    private String member_specie;
    private String member_age;
    private String member_bday;
    private String member_memo;

    public String getMember_memo() {
        return member_memo;
    }

    public void setMember_memo(String member_memo) {
        this.member_memo = member_memo;
    }

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public String getMember_name() {
        return member_name;
    }

    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }

    public String getMember_sex() {
        return member_sex;
    }

    public void setMember_sex(String member_sex) {
        this.member_sex = member_sex;
    }

    public String getMember_specie() {
        return member_specie;
    }

    public void setMember_specie(String member_specie) {
        this.member_specie = member_specie;
    }

    public String getMember_age() {
        return member_age;
    }

    public void setMember_age(String member_age) {
        this.member_age = member_age;
    }

    public String getMember_bday() {
        return member_bday;
    }

    public void setMember_bday(String member_bday) {
        this.member_bday = member_bday;
    }
}
