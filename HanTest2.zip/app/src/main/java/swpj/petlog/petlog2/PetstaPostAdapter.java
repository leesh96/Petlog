package swpj.petlog.petlog2;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/*public class PetstaPostAdapter extends RecyclerView.Adapter<PetstaPostAdapter.CustomViewHolder>{
    private ArrayList<PetstaPostData> mList = null;
    private Activity context = null;

    public interface OnItemClickListner{
        void onItemClick(View v, int pos);
    }

    private OnItemClickListner mListener = null;

    public void setOnItemClickListener (DiaryAdapter.OnItemClickListener listener) {
        this.mListener = listener;
    }
    public PetstaPostAdapter(Activity context, ArrayList<PetstaPostData> list){
        this.context = context;
        this.mList = list;
    }
    class CustomViewHolder extends RecyclerView.ViewHolder{
        private TextView
    }
}*/

