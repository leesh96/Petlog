package swpj.petlog.petlog2;

public class ProfileData {
    String member_nickname;
    private String member_contents;

    public ProfileData(String member_nickname, String member_contents){
        this.member_nickname = member_nickname;
        this.member_contents = member_contents;
    }

    public String getMember_nickname() {
        return member_nickname;
    }

    public void setMember_nickname(String member_nickname) {
        this.member_nickname = member_nickname;
    }

    public String getMember_contents() {
        return member_contents;
    }

    public void setMember_contents(String member_contents) {
        this.member_contents = member_contents;
    }
}
