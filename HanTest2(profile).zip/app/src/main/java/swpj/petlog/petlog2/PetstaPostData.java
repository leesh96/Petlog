package swpj.petlog.petlog2;

public class PetstaPostData {
    private int member_nickname;
    private String member_content;

    public int getMember_nickname() {
        return member_nickname;
    }

    public void setMember_nickname(int member_nickname) {
        this.member_nickname = member_nickname;
    }

    public String getMember_contents() {
        return member_content;
    }

    public void setMember_contents(String member_contents) {
        this.member_content = member_content;
    }
}
