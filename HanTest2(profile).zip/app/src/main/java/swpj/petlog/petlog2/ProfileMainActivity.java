package swpj.petlog.petlog2;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.selection.SelectionTracker;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ProfileMainActivity extends AppCompatActivity {
    private static String PHPURL = "http://128.199.106.86/getProfile.php";
    private static String TAG = "getprofile";
    private Button btn_profilewrite;
    private TextView show_profile_nickname, show_profile_text_me;
    private RecyclerView profile_rv;
    private String jsonString;
    private ArrayList<ProfileData> arrayList;
    private ProfileAdapter profileAdapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.petsta_profile_main);

        final String nickname = PreferenceManager.getString(ProfileMainActivity.this, "userNick");

        btn_profilewrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileMainActivity.this, AddProfileActivity.class);
                startActivity(intent);
            }
        });

        show_profile_nickname = (TextView) findViewById(R.id.show_profile_nickname);
        profile_rv = (RecyclerView) findViewById(R.id.profile_rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        profile_rv.setLayoutManager(layoutManager);

        arrayList = new ArrayList<>();

        profileAdapter = new ProfileAdapter(this, arrayList);
        profile_rv.setAdapter(profileAdapter);
        arrayList.clear();
        profileAdapter.notifyDataSetChanged();

        GetData task = new GetData();
        task.execute(PHPURL, nickname, "");

        profileAdapter.setOnItemClickListener(new ProfileAdapter.OnItemClickListener() {
            public void onItemClick(View v, int position) {
                ProfileData profileData = arrayList.get(position);

                Intent intent = new Intent(ProfileMainActivity.this, ShowProfileActivity.class);
                intent.putExtra("nickname", profileData.getMember_nickname());
                intent.putExtra("profile_content", profileData.getMember_contents());
                startActivity(intent);
            }
        });
    }

    private class GetData extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;
        String errorString = null;

        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(ProfileMainActivity.this,
                    "Please Wait", null, true, true);
        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            //mTextViewResult.setText(result);
            Log.d(TAG, "response - " + result);

            if (result == null) {
                //mTextViewResult.setText(errorString);
            } else {
                jsonString = result;
                showResult();
            }
        }

        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String nickname = (String) params[1];
            String contents = (String) params[2];

            String postParameters = "nickname=" + nickname + "&contents=" + contents;

            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if (responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                } else {
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString().trim();

            } catch (Exception e) {
                Log.d(TAG, "GetData : Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }

    private void showResult() {

        String TAG_JSON = "petsta_profile";
        String TAG_NICKNAME = "nickname";
        String TAG_CONTENTS = "contents";

        try {
            JSONObject jsonObject = new JSONObject(jsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject item = jsonArray.getJSONObject(i);

                String nickname = item.getString(item.getString(TAG_NICKNAME));
                String Contents = item.getString(TAG_CONTENTS);

                ProfileData profileData = new ProfileData(nickname, Contents);

                profileData.setMember_nickname(nickname);
                profileData.setMember_contents(Contents);

                arrayList.add(profileData);
                profileAdapter.notifyDataSetChanged();
            }

        } catch (JSONException e) {
            Log.d(TAG, "showResult : ", e);
        }
    }
}
