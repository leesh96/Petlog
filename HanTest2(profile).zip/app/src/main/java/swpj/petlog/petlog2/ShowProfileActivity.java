package swpj.petlog.petlog2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ShowProfileActivity extends AppCompatActivity {
    private ImageView show_profile_image;
    private TextView show_profile_nickname, show_profile_text_me;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_show);

        show_profile_image = (ImageView) findViewById(R.id.show_profile_image);
        show_profile_nickname = (TextView) findViewById(R.id.show_profile_nickname);
        show_profile_text_me = (TextView) findViewById(R.id.show_profile_text_me);

        final String getContents = getIntent().getStringExtra("profile_content");
        final String getNickName = getIntent().getStringExtra("nickname");


    }
}
