package swpj.petlog.petlog2;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProfileAdapter extends RecyclerView.Adapter<ProfileAdapter.CustomViewHolder>{
    private ArrayList<ProfileData> mList = null;
    private Activity context = null;

    public interface OnItemClickListener{
        void onItemClick(View v, int pos);
    }

    private OnItemClickListener mListener = null;

    public void setOnItemClickListener (OnItemClickListener listener) {this.mListener = listener;}

    public ProfileAdapter(Activity context, ArrayList<ProfileData> list){
        this.context = context;
        this.mList = list;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder{
        private TextView tv_profile_nickname, tv_profile_text_me;

        public CustomViewHolder(View view){
            super(view);
            this.tv_profile_nickname = (TextView) view.findViewById(R.id.tv_profile_nickname);
            this.tv_profile_text_me = (TextView) view.findViewById(R.id.tv_profile_text_me);

            view.setOnClickListener(new View.OnClickListener() {
                public  void onClick(View v){
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION){
                        if(mListener != null) mListener.onItemClick(v, pos);
                    }
                }
            });
        }
    }

    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType){
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.profile_data, null);
        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    public void onBindViewHolder(CustomViewHolder viewHolder, int position){
        viewHolder.tv_profile_nickname.setText(mList.get(position).getMember_nickname());
        viewHolder.tv_profile_text_me.setText(mList.get(position).getMember_contents());
    }

    public int getItemCount(){return (null != mList ? mList.size() : 0);}
}
