package swpj.petlog.petlog2;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ModuleInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddProfileActivity extends AppCompatActivity {
    private static String TAG = "profile";
    private static String PHPURL = "http://128.199.106.86/addProfile.php";
    private ImageView petsta_profile_image;
    private EditText profile_text_me;
    private Button profile_upload_btn;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_profile);

        petsta_profile_image = (ImageView) findViewById(R.id.petsta_profile_image);
        profile_text_me = (EditText) findViewById(R.id.profile_text_me);
        profile_upload_btn = (Button) findViewById(R.id.profile_upload_btn);

        profile_upload_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String contents = profile_text_me.getText().toString();
                String nickname = PreferenceManager.getString(AddProfileActivity.this,"userNick");

                InsertData task = new InsertData();
                task.execute(PHPURL,contents,nickname);

                Intent intent = new Intent(AddProfileActivity.this, ProfileMainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    class InsertData extends AsyncTask<String,Void, String>{
        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {

            String contents = (String)params[1];
            String nickname = (String)params[2];

            String serverURL = (String)params[0];
            String postParameters = "&contents=" + contents + "&nickname" + nickname;

            try{
                URL url = new URL(serverURL);

                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString();
            } catch (Exception e){
                Log.d(TAG, "InsertData: Error ", e);
                return new String("Error: " + e.getMessage());
            }
        }

        protected void onPreExecute(){
            super.onPreExecute();

            progressDialog = ProgressDialog.show(AddProfileActivity.this,
                    "Please Wait", null, true, true);
        }

        protected void onPostExecute(String result){
            super.onPostExecute(result);
            progressDialog.dismiss();
            Log.d(TAG, "POST response - "+ result);
        }
    }

}