package com.swp.petlog.setting;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.swp.petlog.R;

public class PushActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_pushalert);

    };
}

